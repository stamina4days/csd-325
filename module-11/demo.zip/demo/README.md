# Module 11.2 Django Basics

Author: Prince Hubbard
Course: CSD325 Advanced Python
Assignment: 11.2 Django Basics

## Purpose
This small Django project demonstrates a project, an app, a URL route, and an `HttpResponse` view. Visiting the home page displays `Hubbard says Hello!`.

## Run on Windows
From the folder containing `manage.py`:

```bat
py -m pip install -r requirements.txt
py manage.py runserver
```

Open http://127.0.0.1:8000/ in a browser. Press Ctrl+C in the command window to stop the server.

## Files
- `manage.py`: Django command entry point.
- `demo/settings.py`: Project configuration and app registration.
- `demo/urls.py`: Routes the home page to the app.
- `hubbard/urls.py`: Maps the empty path to the index view.
- `hubbard/views.py`: Returns the assignment greeting.

## Sources
Django Software Foundation. Writing your first Django app, part 1. https://docs.djangoproject.com/en/5.2/intro/tutorial01/
