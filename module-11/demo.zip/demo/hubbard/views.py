"""A simple greeting view for the Module 11 Django assignment."""

from django.http import HttpResponse


def index(request):
    """Return the requested greeting for the home page."""
    return HttpResponse("Hubbard says Hello!")
